var protocol_flurry_ad_banner_delegate_p =
[
    [ "adBanner:adError:errorDescription:", "protocol_flurry_ad_banner_delegate-p.html#a29db921606153bbbdfc76260aa8c3942", null ],
    [ "adBannerDidDismissFullscreen:", "protocol_flurry_ad_banner_delegate-p.html#a50be31f2577ec1ff3a4789b23715bd29", null ],
    [ "adBannerDidFetchAd:", "protocol_flurry_ad_banner_delegate-p.html#a53aa67e44dc264173ece6c1bcd333054", null ],
    [ "adBannerDidReceiveClick:", "protocol_flurry_ad_banner_delegate-p.html#a606f03026e78a90c82442e4e893bf8d5", null ],
    [ "adBannerDidRender:", "protocol_flurry_ad_banner_delegate-p.html#a27719ff9204e8d3201c677300c9e9a47", null ],
    [ "adBannerVideoDidFinish:", "protocol_flurry_ad_banner_delegate-p.html#a513643cdc61bad82fe502a8a62feacbf", null ],
    [ "adBannerWillDismissFullscreen:", "protocol_flurry_ad_banner_delegate-p.html#ae7c2c86e4cd9869fb97cef78484a33e0", null ],
    [ "adBannerWillLeaveApplication:", "protocol_flurry_ad_banner_delegate-p.html#aebc97c95931c473a78581b774520ba3d", null ],
    [ "adBannerWillPresentFullscreen:", "protocol_flurry_ad_banner_delegate-p.html#a639722aced118d82e5fe670b51159c38", null ]
];