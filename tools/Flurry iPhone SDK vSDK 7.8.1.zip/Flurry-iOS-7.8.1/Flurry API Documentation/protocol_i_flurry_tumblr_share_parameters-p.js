var protocol_i_flurry_tumblr_share_parameters_p =
[
    [ "androidDeepLink", "protocol_i_flurry_tumblr_share_parameters-p.html#acd4f1247c5dea8294ec615d1ca331fbf", null ],
    [ "iOSDeepLink", "protocol_i_flurry_tumblr_share_parameters-p.html#a4db804a82877458a480cfdf0ddd1a4a0", null ],
    [ "webLink", "protocol_i_flurry_tumblr_share_parameters-p.html#af4b4b585118a74e51b6dcb43058cb923", null ]
];