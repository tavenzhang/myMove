var protocol_flurry_ad_native_delegate_p =
[
    [ "adNative:adError:errorDescription:", "protocol_flurry_ad_native_delegate-p.html#a8815fca110a389d44754ae3b995f2c97", null ],
    [ "adNativeDidDismiss:", "protocol_flurry_ad_native_delegate-p.html#aef9b695e48670156d1c9ca9030e0fa8b", null ],
    [ "adNativeDidFetchAd:", "protocol_flurry_ad_native_delegate-p.html#a145a00a1cfd5526c157bdbcf7af7a4a8", null ],
    [ "adNativeDidLogImpression:", "protocol_flurry_ad_native_delegate-p.html#a9fd3605a6413e3918296e2ec5db418fc", null ],
    [ "adNativeDidReceiveClick:", "protocol_flurry_ad_native_delegate-p.html#a74707f0902106972554b42a36495733b", null ],
    [ "adNativeExpandToggled:", "protocol_flurry_ad_native_delegate-p.html#a27cbc783d56a333c7639e96f8aba5637", null ],
    [ "adNativeWillDismiss:", "protocol_flurry_ad_native_delegate-p.html#a2f5f3d7b688c95240f51140c848404d3", null ],
    [ "adNativeWillLeaveApplication:", "protocol_flurry_ad_native_delegate-p.html#a257a0d54437bfffdb184e7a1464ad7cd", null ],
    [ "adNativeWillPresent:", "protocol_flurry_ad_native_delegate-p.html#a65b451548e89f3bd16e48ce8dfcb9363", null ]
];