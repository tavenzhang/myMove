var protocol_flurry_tumblr_delegate_p =
[
    [ "flurryTumblrPostError:errorType:", "protocol_flurry_tumblr_delegate-p.html#a775f879e43620bd1f6247fe38ebd31bb", null ],
    [ "flurryTumblrPostSuccess", "protocol_flurry_tumblr_delegate-p.html#a0f0fcc346404624370571c393dda0d77", null ]
];