var interface_flurry_ad_targeting =
[
    [ "keywords", "interface_flurry_ad_targeting.html#a27cce26d3aaa140baf1f8379dd62145c", null ],
    [ "location", "interface_flurry_ad_targeting.html#a2600adbd7bc010f3733dabe2581ccfd8", null ],
    [ "testAdsEnabled", "interface_flurry_ad_targeting.html#a1c85fc0043d8909f1254a3d9145c7994", null ],
    [ "userCookies", "interface_flurry_ad_targeting.html#af9f7f2f48713ab6699394fa080c7963c", null ]
];