var interface_flurry_ad_native_style =
[
    [ "initWithStyle:", "interface_flurry_ad_native_style.html#a5bb31f8e74e13e15c58d6ca1a3cbf3e4", null ],
    [ "style", "interface_flurry_ad_native_style.html#aa55457625a301bdbcb41e07c6069c718", null ]
];