var searchData=
[
  ['withappversion_3a',['withAppVersion:',['../interface_flurry_session_builder.html#a759df1999a1212d59b7153cc7524da6e',1,'FlurrySessionBuilder']]],
  ['withcrashreporting_3a',['withCrashReporting:',['../interface_flurry_session_builder.html#a8bf13ca5dd0d60d56d2619982a3b06f6',1,'FlurrySessionBuilder']]],
  ['withloglevel_3a',['withLogLevel:',['../interface_flurry_session_builder.html#ac891dc68740af34d6aad9098981e1cd0',1,'FlurrySessionBuilder']]],
  ['withsessioncontinueseconds_3a',['withSessionContinueSeconds:',['../interface_flurry_session_builder.html#a1c8910aefa70cc2f76cc5b21ed6c34ef',1,'FlurrySessionBuilder']]],
  ['withshowerrorinlog_3a',['withShowErrorInLog:',['../interface_flurry_session_builder.html#ad23c59d06218aba6cd9e4700d7a3564f',1,'FlurrySessionBuilder']]]
];
