var interface_flurry_text_share_parameters =
[
    [ "text", "interface_flurry_text_share_parameters.html#ab2d928a8f65099a9afb7436b68cc2e8d", null ],
    [ "title", "interface_flurry_text_share_parameters.html#ae69f60a575459eb16dfab684dfd2c789", null ]
];