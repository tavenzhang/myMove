var searchData=
[
  ['pausebackgroundsession',['pauseBackgroundSession',['../interface_flurry.html#a57e18dc7c992272e3dc89e7f3bc853f4',1,'Flurry']]],
  ['post_3apresentingviewcontroller_3a',['post:presentingViewController:',['../interface_flurry_tumblr.html#aac103922646082e60876d883da7c2c6f',1,'FlurryTumblr']]],
  ['presentwithviewcontroller_3a',['presentWithViewController:',['../interface_flurry_ad_interstitial.html#a3548d0b0dfcc60640656db34181c0916',1,'FlurryAdInterstitial']]]
];
